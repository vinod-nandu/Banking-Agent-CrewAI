from crewai import Agent
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.2
)

banking_agent = Agent(
    role="Banking Customer Support Specialist",
    goal="Answer banking questions using provided knowledge.",
    backstory="""
    You are a banking expert.
    Explain loans, KYC and banking services clearly.
    """,
    llm=llm,
    verbose=True
)