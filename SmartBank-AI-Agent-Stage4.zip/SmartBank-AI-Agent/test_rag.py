from rag.document_loader import load_documents
from rag.text_splitter import split_documents
from rag.vector_store import create_vector_store
from rag.retriever import search_documents

docs = load_documents("documents/Home_Loan_Policy.pdf")
chunks = split_documents(docs)
db = create_vector_store(chunks)

results = search_documents(
    db,
    "What documents are required for home loan?"
)

for r in results:
    print(r.page_content)