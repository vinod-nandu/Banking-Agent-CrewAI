import streamlit as st

st.title("SmartBank AI Assistant")

question = st.chat_input("Ask your banking question")

if question:
    st.write("Question:", question)
    st.write("RAG + CrewAI integration will be added in Stage 5.")