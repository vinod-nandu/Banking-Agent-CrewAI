def search_documents(vector_db, question):
    return vector_db.similarity_search(question, k=3)